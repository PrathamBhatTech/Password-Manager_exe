This is a Password Manager made using python by Pratham Bhat.
The data is encrypted before being stored using the cryptography library of python You can create multiple users and each user will have their own table to store their encrypted username and password.
The encrypted username and password for the users is stored in a separate table.
This version uses classes and is more efficient and developed than the non class version.

By Pratham Bhat. GITHUB account - Batflash2